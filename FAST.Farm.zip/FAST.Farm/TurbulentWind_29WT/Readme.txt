1. Run Turbsim to generate InflowWind_High_WT1.bts to InflowWind_High_W30.bts

2. Run Turbsim to generate  InflowWind_Low_Farm.bts

3. Dowload FAST.Farm_x64_OMP.exe (V3.5.1) to this directory 

4. Run FAST.Farm
cd [Your directory]

.\FAST.Farm_x64_OMP.exe IEA_15_Semi_Farm.fstf

5. Download matlab_toolbox(https://github.com/OpenFAST/matlab-toolbox) and add it to your directory 

6. Using ReadFastOut.m in MATLAB and to extract outputs